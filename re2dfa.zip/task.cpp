#include "api.hpp"
#include <string>

DFA re2dfa(const std::string &s) {
	DFA res = DFA(Alphabet(s));
	res.create_state("Start", true);
	res.set_initial("Start");
	return res;
}
